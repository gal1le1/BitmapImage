#include <stdio.h>

int main(int argc, char const *argv[])
{
    int i;
    for (i = 0; i < 10; i++)
    {
        printf("%d   \n", i);
        if (i == 2)
        {
            i+=2;
        }
        
    }
    
    return 0;
}
